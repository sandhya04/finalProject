package com.company.FlightTicket.dao;

import org.springframework.data.repository.CrudRepository;

import com.company.FlightTicket.dto.PassengerRequestDto;
import com.company.FlightTicket.model.Passenger;

public interface PassengerRepository extends CrudRepository<Passenger,PassengerRequestDto>{

}

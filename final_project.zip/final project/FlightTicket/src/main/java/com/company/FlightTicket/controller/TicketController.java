package com.company.FlightTicket.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.company.FlightTicket.dto.TicketRequestDto;
import com.company.FlightTicket.dto.TicketResponseDto;
import com.company.FlightTicket.service.TicketService;


@RestController
public class TicketController {
	private final Logger LOGGER=LoggerFactory.getLogger(TicketController.class);
	
	@Autowired
	TicketService ticketService;
	
	@Autowired
	RestTemplate restTemplate;
	
	/*
	 * booking flight ticket
	 * 
	 * @param- ticketrequestDto
	 * 
	 * @result-ticket Id
	 */
	@PostMapping("/tickets")
	public ResponseEntity<String> bookTicket(@RequestBody TicketRequestDto ticketRequestDto){
		LOGGER.info("booking the ticket");
		long ticketId=ticketService.bookTicket(ticketRequestDto);
		return new ResponseEntity<String>("success. your ticket id is "+ticketId ,HttpStatus.OK);
	}
	
	/*
	 * getting status of ticket id
	 * 
	 * @param- ticketId
	 * 
	 * @result-ticket details
	 */
	@GetMapping("/tickets")
	public ResponseEntity<TicketResponseDto> getStatus(@RequestParam("ticketId") Long ticketId ) {
		TicketResponseDto ticketResponseDto= ticketService.getStatus(ticketId);
		return new ResponseEntity<TicketResponseDto>(ticketResponseDto,HttpStatus.OK);
	}
	
	
}

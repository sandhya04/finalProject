package com.company.FlightTicket.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Passenger {
	
	@EmbeddedId
	private PassengerCompositeKey passengerCompositeKey;
	private String name;
	private int age;
	private String gender;
	
	public PassengerCompositeKey getPassengerCompositeKey() {
		return passengerCompositeKey;
	}
	public void setPassengerCompositeKey(PassengerCompositeKey passengerCompositeKey) {
		this.passengerCompositeKey = passengerCompositeKey;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
}

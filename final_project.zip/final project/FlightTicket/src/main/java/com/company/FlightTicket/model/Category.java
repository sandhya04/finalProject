package com.company.FlightTicket.model;

import org.springframework.stereotype.Component;

@Component
public class Category {
	
	
	private String flightId;
	private int noOfBusinessSeats;
	private double businessSeatCost;
	private int noOfEconomicSeats;
	private double economicSeatCost;
	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	public int getNoOfBusinessSeats() {
		return noOfBusinessSeats;
	}
	public void setNoOfBusinessSeats(int noOfBusinessSeats) {
		this.noOfBusinessSeats = noOfBusinessSeats;
	}
	public double getBusinessSeatCost() {
		return businessSeatCost;
	}
	public void setBusinessSeatCost(double businessSeatCost) {
		this.businessSeatCost = businessSeatCost;
	}
	public int getNoOfEconomicSeats() {
		return noOfEconomicSeats;
	}
	public void setNoOfEconomicSeats(int noOfEconomicSeats) {
		this.noOfEconomicSeats = noOfEconomicSeats;
	}
	public double getEconomicSeatCost() {
		return economicSeatCost;
	}
	public void setEconomicSeatCost(double economicSeatCost) {
		this.economicSeatCost = economicSeatCost;
	}
}

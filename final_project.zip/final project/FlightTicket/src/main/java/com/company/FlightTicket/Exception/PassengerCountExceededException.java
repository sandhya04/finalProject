package com.company.FlightTicket.Exception;

public class PassengerCountExceededException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	public PassengerCountExceededException(String exception){
		super(exception);
	}

}

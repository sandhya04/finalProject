package com.company.FlightTicket.Exception;

public class TicketDetailsNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	public TicketDetailsNotFoundException(String exception) {
		super(exception);
	}

}

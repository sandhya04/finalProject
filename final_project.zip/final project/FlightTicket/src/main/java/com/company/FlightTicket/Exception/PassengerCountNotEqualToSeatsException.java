package com.company.FlightTicket.Exception;

public class PassengerCountNotEqualToSeatsException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	public PassengerCountNotEqualToSeatsException(String exception) {
		super(exception);
	}

}

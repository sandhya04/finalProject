package com.company.FlightTicket.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name="seq",initialValue=10001)
public class Ticket {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "seq")
	private Long ticketId;
	private long userId;
	private String flightId;
	private int noOfSeats;
	private String airportId;
	private String category;
	private Date date;

	public Long getTicketId() {
		return ticketId;
	}

	/*
	 * public void setTicketId(Long ticketId) { this.ticketId = ticketId; }
	 */
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public String getAirportId() {
		return airportId;
	}
	public void setAirportId(String airportId) {
		this.airportId = airportId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	
}

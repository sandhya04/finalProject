package com.company.FlightTicket.Exception;

public class SeatsNotAvailableException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	public SeatsNotAvailableException(String exception) {
		super(exception);
	}

}

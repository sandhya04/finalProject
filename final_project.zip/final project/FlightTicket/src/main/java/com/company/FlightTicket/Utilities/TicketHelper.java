package com.company.FlightTicket.Utilities;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import com.company.FlightTicket.dto.TicketResponseDto;
import com.company.FlightTicket.model.Category;
import com.company.FlightTicket.model.Flight;
import com.company.FlightTicket.model.Ticket;

@Component
public class TicketHelper {
	
	@Autowired
	JavaMailSender javaMailSender;

	public TicketResponseDto setTicketResponseDto(Flight flight, TicketResponseDto ticketResponseDto, Category category,Ticket ticket) {
		// TODO Auto-generated method stub
		ticketResponseDto.setSource(flight.getSource());
		ticketResponseDto.setDestination(flight.getDestination());
		ticketResponseDto.setArrivalTime(flight.getArrivalTime());
		ticketResponseDto.setDepartureTime(flight.getDepartureTime());
		ticketResponseDto.setDate(flight.getDate());
		if(ticketResponseDto.getCategory().equalsIgnoreCase("economic")) 
			ticketResponseDto.setTotalCost(category.getEconomicSeatCost() * ticket.getNoOfSeats());
		else
			ticketResponseDto.setTotalCost(category.getBusinessSeatCost() * ticket.getNoOfSeats());
		return ticketResponseDto;
	}
	
	public void sendMail(Ticket ticket) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo("sandhyahathwar03@gmail.com");
		message.setSubject("Booking Confirmation");
		message.setText("your ticket is confirmed. your ticket id is "+ticket.getTicketId());
		javaMailSender.send(message);
	}

}

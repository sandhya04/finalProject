package com.company.FlightTicket.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.company.FlightTicket.Exception.PassengerCountExceededException;
import com.company.FlightTicket.Exception.PassengerCountNotEqualToSeatsException;
import com.company.FlightTicket.Exception.PassengerNotAvailableException;
import com.company.FlightTicket.Exception.SeatsNotAvailableException;
import com.company.FlightTicket.Exception.TicketDetailsNotFoundException;
import com.company.FlightTicket.Utilities.PassengerHelper;
import com.company.FlightTicket.Utilities.TicketHelper;
import com.company.FlightTicket.dao.PassengerRepository;
import com.company.FlightTicket.dao.TicketRepository;
import com.company.FlightTicket.dto.PassengerRequestDto;
import com.company.FlightTicket.dto.TicketRequestDto;
import com.company.FlightTicket.dto.TicketResponseDto;
import com.company.FlightTicket.model.Category;
import com.company.FlightTicket.model.Flight;
import com.company.FlightTicket.model.Passenger;
import com.company.FlightTicket.model.Ticket;

@Service
public class TicketServiceImpl implements TicketService{
	
	@Autowired
	TicketRepository ticketRepository;
	
	@Autowired
	ModelMapper modelMapper;

	@Autowired
	PassengerRepository passengerRepository;
	
	@Autowired
	PassengerHelper passengerHelper;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	TicketHelper ticketHelper;
	
	/* booking flight tickets. */
	@Override
	public long bookTicket(TicketRequestDto ticketRequestDto) {
		// TODO Auto-generated method stub
		Ticket ticket=modelMapper.map(ticketRequestDto, Ticket.class);
		List<Passenger> passengerList = new ArrayList<Passenger>();
		
		if(ticketRequestDto.getNoOfSeats()!= ticketRequestDto.getPassengerList().size()) throw new PassengerCountNotEqualToSeatsException("Passenger count not equal to no of seats specified");
		if(ticketRequestDto.getPassengerList().size()>3 ) throw new PassengerCountExceededException("User can book upto 3 passengers only");
		if(ticketRequestDto.getPassengerList().isEmpty())  throw new PassengerNotAvailableException("please enter passenger details ");
		for(PassengerRequestDto passengerDto: ticketRequestDto.getPassengerList()) {
			Passenger passenger=modelMapper.map(passengerDto,Passenger.class);
			passenger=passengerHelper.setCompositeKey(passenger, ticketRequestDto);
			passengerList.add(passenger);
		}
		
	
		int noOfSeats=0;		
		if(ticketRequestDto.getCategory().equalsIgnoreCase("economic")) 
			noOfSeats=restTemplate.getForObject("http://SEARCH/flight/availableEconomicSeats?flightId="+ticketRequestDto.getFlightId(), Integer.class);
		else
			noOfSeats=restTemplate.getForObject("http://SEARCH/flight/availableBusinessSeats?flightId="+ticketRequestDto.getFlightId(), Integer.class);
		
		if(noOfSeats<ticketRequestDto.getNoOfSeats()) throw new SeatsNotAvailableException("seats not available ");
			
		restTemplate.getForObject("http://SEARCH/flight/flights/"+ticketRequestDto.getFlightId(), Flight.class);
		restTemplate.getForObject("http://SEARCH/flight/airports/"+ticketRequestDto.getAirportId(), ResponseEntity.class);
		restTemplate.getForObject("http://USERS/user/users/"+ticketRequestDto.getUserId(), ResponseEntity.class);
		
		ticketRepository.save(ticket);
		passengerRepository.saveAll(passengerList);
		
		restTemplate.postForObject("http://SEARCH/flight/updateSeats?flightId="+ticket.getFlightId()+"&categoryType="+ticket.getCategory()+"&noOfSeats="+ticket.getNoOfSeats(),null,ResponseEntity.class);
		ticketHelper.sendMail(ticket);
		return ticket.getTicketId();
		
		
		
	}

	/* getting ticket details */
	@Override
	public TicketResponseDto getStatus(Long ticketId) {
		// TODO Auto-generated method stub
		Optional<Ticket> ticket=ticketRepository.findById(ticketId);
		if(!ticket.isPresent()) throw new TicketDetailsNotFoundException("ticketId not found "+ticketId);
		TicketResponseDto ticketResponseDto=modelMapper.map(ticket.get(),TicketResponseDto.class);
		
		Flight flight=restTemplate.getForObject("http://SEARCH/flight/flights/"+ticket.get().getFlightId(), Flight.class);
		Category category=restTemplate.getForObject("http://SEARCH/flight/Category/"+ticket.get().getFlightId(), Category.class);
		
		ticketResponseDto=ticketHelper.setTicketResponseDto(flight, ticketResponseDto,category,ticket.get());
		return ticketResponseDto;
	}

}

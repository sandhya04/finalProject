package com.company.FlightTicket.service;

import com.company.FlightTicket.dto.TicketRequestDto;
import com.company.FlightTicket.dto.TicketResponseDto;

public interface TicketService {

	long bookTicket(TicketRequestDto ticketRequestDto);

	TicketResponseDto getStatus(Long ticketId);

}

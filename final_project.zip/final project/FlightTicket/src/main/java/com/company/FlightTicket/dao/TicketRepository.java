package com.company.FlightTicket.dao;

import org.springframework.data.repository.CrudRepository;

import com.company.FlightTicket.model.Ticket;

public interface TicketRepository extends CrudRepository<Ticket,Long>{

}

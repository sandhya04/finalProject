package com.company.FlightTicket.ExceptionHandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.company.FlightTicket.Exception.PassengerCountExceededException;
import com.company.FlightTicket.Exception.PassengerCountNotEqualToSeatsException;
import com.company.FlightTicket.Exception.PassengerNotAvailableException;
import com.company.FlightTicket.Exception.SeatsNotAvailableException;
import com.company.FlightTicket.Exception.TicketDetailsNotFoundException;

@ControllerAdvice
public class TicketExceptionController {

	@ExceptionHandler(PassengerNotAvailableException.class)
	public ResponseEntity<Error> handleException(PassengerNotAvailableException exception){
		Error error = new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());
		error.setSuggestion("passenger not available");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(PassengerCountExceededException.class)
	public ResponseEntity<Error> handleException(PassengerCountExceededException exception){
		Error error = new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());
		error.setSuggestion("passenger count exceeded");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(TicketDetailsNotFoundException.class)
	public ResponseEntity<Error> handleException(TicketDetailsNotFoundException exception){
		Error error = new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());
		error.setSuggestion("Journey details not Found");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(SeatsNotAvailableException.class)
	public ResponseEntity<Error> handleException(SeatsNotAvailableException exception){
		Error error = new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());
		error.setSuggestion("Not enough seats available");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(PassengerCountNotEqualToSeatsException.class)
	public ResponseEntity<Error> handleException(PassengerCountNotEqualToSeatsException exception){
		Error error = new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());
		error.setSuggestion("passenger count not equal");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}
}

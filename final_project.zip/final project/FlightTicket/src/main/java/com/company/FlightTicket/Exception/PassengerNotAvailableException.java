package com.company.FlightTicket.Exception;

public class PassengerNotAvailableException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	public PassengerNotAvailableException(String exception) {
		super(exception);
	}

}

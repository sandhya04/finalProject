package com.company.FlightTicket.Utilities;

import org.springframework.stereotype.Component;

import com.company.FlightTicket.dto.TicketRequestDto;
import com.company.FlightTicket.model.Passenger;
import com.company.FlightTicket.model.PassengerCompositeKey;

@Component
public class PassengerHelper {

	private static long id=1;
	public Passenger setCompositeKey(Passenger passenger,TicketRequestDto ticketRequestDto) {
		PassengerCompositeKey passengerCompositeKey=new PassengerCompositeKey();
		passengerCompositeKey.setUserId(ticketRequestDto.getUserId());
		passengerCompositeKey.setPassengerId(id++);
		passenger.setPassengerCompositeKey(passengerCompositeKey);
		return passenger;
	}
}

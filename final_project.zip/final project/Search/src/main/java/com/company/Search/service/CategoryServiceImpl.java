package com.company.Search.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.Search.Exception.FlightNotFoundException;
import com.company.Search.dao.CategoryRepository;
import com.company.Search.model.Category;
import com.company.Search.model.Flight;

@Service
public class CategoryServiceImpl implements CategoryService{


	@Autowired
	CategoryRepository categoryRepository;

	@Override
	public int getEconomicSeats(String flightId) {
		// TODO Auto-generated method stub
		Category category=getById(flightId);		
		return category.getNoOfEconomicSeats();
	}

	@Override
	public int getBusinessSeats(String flightId) {
		// TODO Auto-generated method stub
		Category category=getById(flightId);
			return category.getNoOfBusinessSeats();
	}
	
	@Override
	public  Category getById(String flightId) {
		Optional<Category> category=categoryRepository.findById(flightId);
		if(!category.isPresent()) throw new FlightNotFoundException("Flight does not exists "+flightId);
		return category.get();
	}
	
	@Override
	public void updateSeats(String flightId,String CategoryType,int noOfSeats){
		Category category=getById(flightId);
		if(CategoryType.equalsIgnoreCase("economic")) 
			category.setNoOfEconomicSeats(category.getNoOfEconomicSeats()-noOfSeats);
		else
			category.setNoOfBusinessSeats(category.getNoOfBusinessSeats()-noOfSeats);
		
		categoryRepository.save(category);
	}
	
	/*
	 * @Override public List<Category> getCategory(List<Flight> flightList) { //
	 * TODO Auto-generated method stub List<String> flightIdList=new
	 * ArrayList<String>(); for(Flight flight:flightList) {
	 * flightIdList.add(flight.getFlightId()); } List<Category>
	 * categoryList=(List<Category>) categoryRepository.findAllById(flightIdList);
	 * return categoryList; }
	 */
}

package com.company.Search.Exception;

public class SourceDestinationNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public SourceDestinationNotFoundException(String exception) {
		super(exception);
	}
}

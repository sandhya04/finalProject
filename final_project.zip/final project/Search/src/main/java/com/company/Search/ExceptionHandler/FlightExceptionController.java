package com.company.Search.ExceptionHandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.company.Search.Exception.AirportNotFoundException;
import com.company.Search.Exception.FlightNotFoundException;
import com.company.Search.Exception.SourceDestinationNotFoundException;


@ControllerAdvice
public class FlightExceptionController extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(FlightNotFoundException.class)
	public ResponseEntity<Error> handleException(FlightNotFoundException exception){
		Error error = new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());
		error.setSuggestion("Flight not Found");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(SourceDestinationNotFoundException.class)
	public ResponseEntity<Error> handleException(SourceDestinationNotFoundException exception){
		Error error = new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());
		error.setSuggestion("Flight not found");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(AirportNotFoundException.class)
	public ResponseEntity<Error> handleException(AirportNotFoundException exception){
		Error error = new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());
		error.setSuggestion("Airport not found");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}
	
}

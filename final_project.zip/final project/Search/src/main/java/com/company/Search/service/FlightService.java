package com.company.Search.service;

import java.sql.Date;
import java.util.List;

import com.company.Search.dto.FlightResponseDto;
import com.company.Search.model.Flight;


public interface FlightService {
	public List<FlightResponseDto> getFlights(String source,String destination,Date date);

	public List<FlightResponseDto> getFlightsByName(String source, String destination, Date date, String flightName);

	public List<FlightResponseDto> getFlightsByCost(String source, String destination, Date date, double cost);
	
	public List<FlightResponseDto> getFlightsByNameCost(String source, String destination, Date date,String name, double cost);

	public Flight getFlightById(String flightId);

	FlightResponseDto setFlightResponseDto(Flight flight);


		
}

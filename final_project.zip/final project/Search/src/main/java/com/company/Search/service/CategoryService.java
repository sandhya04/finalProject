package com.company.Search.service;

import java.util.List;

import com.company.Search.model.Category;
import com.company.Search.model.Flight;

public interface CategoryService {
	
	/* public List<Category> getCategory(List<Flight> flightList); */
	public int getEconomicSeats(String flightId);

	public int getBusinessSeats(String flightId);

	Category getById(String flightId);

	void updateSeats(String flightId, String category, int noOfSeats);
}

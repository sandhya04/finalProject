package com.company.Search.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.Search.model.Category;
import com.company.Search.service.CategoryService;

@RestController
public class CategoryController {

	
	@Autowired
	CategoryService categoryService;
	
	/*
	 * getting the available economic seats
	 * 
	 * @param -flight id 
	 * 
	 * @return-number of available economic seats
	 */
	@GetMapping("/availableEconomicSeats")
	public ResponseEntity<Integer> getAvailableEconomicSeats(@RequestParam("flightId") String flightId) {
		int noOfSeats= categoryService.getEconomicSeats(flightId);
		return new ResponseEntity<Integer>(noOfSeats,HttpStatus.OK);
	}
	
	/*
	 * getting the available business seats
	 * 
	 * @param -flight id 
	 * 
	 * @return-number of available business seats
	 */
	@GetMapping("/availableBusinessSeats")
	public ResponseEntity<Integer> getAvailableBusinessSeats(@RequestParam("flightId") String flightId) {
		int noOfSeats= categoryService.getBusinessSeats(flightId);
		return new ResponseEntity<Integer>(noOfSeats,HttpStatus.OK);
	}
	
	/*
	 * getting flights by id.
	 * 
	 * @param- flight id.
	 * 
	 * @return -Category object
	 */
	
	@GetMapping("/Category/{flightId}")
	public ResponseEntity<Category> getById(@PathVariable("flightId")String flightId) {
		Category category= categoryService.getById(flightId);
		return new ResponseEntity<Category>(category,HttpStatus.OK);
		}
	
	/*
	 * updating number of seats in flight.
	 * 
	 * @param flight id, no of seats,categorytype
	 */
	@PostMapping("/updateSeats")
	public ResponseEntity<String> updateSeats(@RequestParam("flightId")String flightId,@RequestParam("noOfSeats") int noOfSeats,@RequestParam("categoryType")String categoryType ) {
		categoryService.updateSeats(flightId, categoryType, noOfSeats);
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
	}
}

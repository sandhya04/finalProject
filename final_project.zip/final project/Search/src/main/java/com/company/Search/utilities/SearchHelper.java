package com.company.Search.utilities;

import java.sql.Time;

import org.springframework.stereotype.Component;

@Component
public class SearchHelper {

	public String setDuration(Time arrivalTime,Time departureTime) {
		String duration= (arrivalTime.getHours()-departureTime.getHours()) +"h :";
		duration +=(arrivalTime.getMinutes()-departureTime.getMinutes())+" m";
		return duration;
	}
}

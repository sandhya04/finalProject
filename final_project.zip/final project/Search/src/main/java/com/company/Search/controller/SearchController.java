package com.company.Search.controller;

import java.sql.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.Search.dto.FlightResponseDto;
import com.company.Search.model.Airport;
import com.company.Search.model.Flight;
import com.company.Search.service.AirportService;
import com.company.Search.service.FlightService;


@RestController
public class SearchController {
	
	@Autowired
	FlightService flightService;
	
	@Autowired
	AirportService airportService;
	
	private final Logger LOGGER=LoggerFactory.getLogger(SearchController.class);
	
	/*
	 * getting the flight details
	 * 
	 * @param -Source ,destination
	 * 
	 * @return-List of flightResponseDto
	 */
	
	@GetMapping("/flights")
	public ResponseEntity<List<FlightResponseDto>> getFlights(@RequestParam("source") String source,@RequestParam("destination") String destination,
			@RequestParam("date")   Date date) {
		List<FlightResponseDto> flightDtoList= flightService.getFlights(source, destination, date);
		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList,HttpStatus.OK);
	}
	
	/*
	 * getting the flight details
	 * 
	 * @param -Source ,destination,flightname
	 * 
	 * @return-List of flightResponseDto
	 */
	@GetMapping("/flights/filterByName")
	public ResponseEntity<List<FlightResponseDto>> getFlightsByName(@RequestParam("source") String source,@RequestParam("destination") String destination,
			@RequestParam("date")   Date date,@RequestParam("name") String flightName){
		List<FlightResponseDto> flightDtoList= flightService.getFlightsByName(source, destination, date,flightName);
		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList,HttpStatus.OK);
	}
	
	/*
	 * getting the flight details
	 * 
	 * @param -Source ,destination,cost
	 * 
	 * @return-List of flightResponseDto
	 */
	
	@GetMapping("/flights/filterByCost")
	public ResponseEntity<List<FlightResponseDto>> getFlightsByCost(@RequestParam("source") String source,@RequestParam("destination") String destination,
			@RequestParam("date")   Date date,@RequestParam("cost") double cost){
		List<FlightResponseDto> flightDtoList= flightService.getFlightsByCost(source, destination, date,cost);
		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList,HttpStatus.OK);
	}
	
	/*
	 * getting the flight details
	 * 
	 * @param -Source ,destination,flightname,cost
	 * 
	 * @return-List of flightResponseDto
	 */
	
	@GetMapping("/flights/filterByNameCost")
	public ResponseEntity<List<FlightResponseDto>> getFlightsByNameCost(@RequestParam("source") String source,@RequestParam("destination") String destination,
			@RequestParam("date")   Date date,@RequestParam("name") String flightName,@RequestParam("cost") double cost){
		List<FlightResponseDto> flightDtoList= flightService.getFlightsByNameCost(source, destination, date,flightName,cost);
		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList,HttpStatus.OK);
	}
		
	
	@GetMapping("/flights/{flightId}")
	public ResponseEntity<Flight> getFlightById(@PathVariable("flightId")String flightId) {
		Flight flight= flightService.getFlightById(flightId);
		return new ResponseEntity<Flight>(flight,HttpStatus.OK);
	}
	
	@GetMapping("/airports/{airportId}")
	public ResponseEntity<Airport> getAirportById(@PathVariable("airportId")String airportId) {
		 airportService.getAirportById(airportId);
		 return new ResponseEntity<Airport>(HttpStatus.OK);
	}
}

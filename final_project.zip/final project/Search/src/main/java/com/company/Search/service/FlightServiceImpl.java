package com.company.Search.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.Search.Exception.FlightNotFoundException;
import com.company.Search.Exception.SourceDestinationNotFoundException;
import com.company.Search.dao.FlightRepository;
import com.company.Search.dto.FlightResponseDto;
import com.company.Search.model.Category;
import com.company.Search.model.Flight;
import com.company.Search.utilities.SearchHelper;

@Service
public class FlightServiceImpl implements FlightService{

	@Autowired
	FlightRepository flightRepository;
	
	@Autowired
	CategoryService categoryService;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	SearchHelper searchHelper;
	
	@Autowired
	FlightService flightService;
	
	List<Flight> flightList=new ArrayList<Flight>();
	List<FlightResponseDto> flightResponseList=new ArrayList<FlightResponseDto>();
	
	/* searching for flights using source,destination and date */
	
	@Override
	public List<FlightResponseDto> getFlights(String source, String destination, Date date) {
		// TODO Auto-generated method stub
		
		flightResponseList.clear();
		
		flightList=flightRepository.findAllBySourceAndDestinationAndDate(source,destination,date);
		
		if(flightList.isEmpty()) throw new FlightNotFoundException("currently no flights available for the given locations."+source+" and "+destination);
		
		flightResponseList=flightList.stream().map(flight->setFlightResponseDto(flight)).collect(Collectors.toList());
		
		return flightResponseList;
	}
	
	@Override
	public FlightResponseDto setFlightResponseDto(Flight flight) {
		FlightResponseDto flightDto=modelMapper.map(flight, FlightResponseDto.class);
		
		Category category=categoryService.getById(flight.getFlightId());
		flightDto.setCostBusinessSeat(category.getBusinessSeatCost());
		flightDto.setCostEconomicSeat(category.getEconomicSeatCost());
		flightDto.setBusinessSeats(category.getNoOfBusinessSeats());
		flightDto.setEconomicSeats(category.getNoOfEconomicSeats());
		flightDto.setDuration(searchHelper.setDuration(flight.getArrivalTime(), flight.getDepartureTime()));
		return flightDto;
	}

	/* filtering the list using flight name. */
	
	@Override
	public List<FlightResponseDto> getFlightsByName(String source, String destination, Date date, String flightName) {
		// TODO Auto-generated method stub
		
	
		if(flightResponseList.isEmpty()) {
			flightResponseList=getFlights( source, destination, date);
		}
		
		List<FlightResponseDto> filteredListByName=flightResponseList.stream().filter(flight->flight.getName().equalsIgnoreCase(flightName)).collect(Collectors.toList());
		
		if(filteredListByName.isEmpty()) throw new FlightNotFoundException("currently no flights available for the given locations."+source+" and "+destination);
		return filteredListByName;
	}

	
	/*
	 * filtering the list using flight cost
	 */
	@Override
	public List<FlightResponseDto> getFlightsByCost(String source, String destination, Date date, double cost) {
		// TODO Auto-generated method stub
		
			if(flightResponseList.isEmpty()) {
				flightResponseList=getFlights( source, destination, date);
			}
	
		
		List<FlightResponseDto> filteredListByCost=flightResponseList.stream().filter(flight->(flight.getCostEconomicSeat()<=cost || flight.getCostBusinessSeat()<=cost) ).collect(Collectors.toList());
	
		if(filteredListByCost.isEmpty()) throw new FlightNotFoundException("currently no flights available for the given locations."+source+" and "+destination);
		return filteredListByCost;
	}
	
	
	
	/* filtering the list using flight cost and flight name */
	@Override
	public List<FlightResponseDto> getFlightsByNameCost(String source, String destination, Date date,String name, double cost) {
		// TODO Auto-generated method stub
		
		List<FlightResponseDto> filteredListByName=flightService.getFlightsByName(source, destination, date, name);
		
		List<FlightResponseDto> filteredListByNameCost=filteredListByName.stream().filter(flight->(flight.getCostEconomicSeat()<=cost || flight.getCostBusinessSeat()<=cost) ).collect(Collectors.toList());
		
		if(filteredListByNameCost.isEmpty()) throw new FlightNotFoundException("currently no flights available for the given locations."+source+" and "+destination);
		return filteredListByNameCost;
	}

	@Override
	public Flight getFlightById(String flightId) {
		// TODO Auto-generated method stub
		Optional<Flight> flight=flightRepository.findById(flightId);
		if(!flight.isPresent()) throw new FlightNotFoundException("flight details not found "+flightId);
		return flight.get();
	}

	
	
}

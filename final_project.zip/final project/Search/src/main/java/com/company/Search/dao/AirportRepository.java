package com.company.Search.dao;

import org.springframework.data.repository.CrudRepository;

import com.company.Search.model.Airport;

public interface AirportRepository extends CrudRepository<Airport,String>{

}

package com.company.Search.Exception;


public class AirportNotFoundException extends RuntimeException{

	
	private static final long serialVersionUID = 1L;
	public AirportNotFoundException(String exception) {
		super(exception);
	}

}

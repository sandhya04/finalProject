package com.company.Search.service;

import com.company.Search.model.Airport;

public interface AirportService {
	public Airport getAirportById(String airportId);
}

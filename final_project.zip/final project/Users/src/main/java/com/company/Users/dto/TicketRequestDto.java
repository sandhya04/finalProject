package com.company.Users.dto;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;


@Component
public class TicketRequestDto {
	
	private String airportId;
	private String flightId;
	private String category;
	private Date date;
	private Long userId;
	private int noOfSeats;
	
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	

	
	List<PassengerRequestDto> passengerList=new ArrayList();
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	
	public String getAirportId() {
		return airportId;
	}
	public void setAirportId(String airportId) {
		this.airportId = airportId;
	}
	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

	public List<PassengerRequestDto> getPassengerList() {
		return passengerList;
	}
	public void setPassengerList(List<PassengerRequestDto> passengerList) {
		this.passengerList = passengerList;
	}

}

package com.company.Users.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.company.Users.dto.FlightResponseDto;
import com.company.Users.dto.TicketRequestDto;
import com.company.Users.dto.TicketResponseDto;

@RestController
public class GatewayController {

	@Autowired
	RestTemplate restTemplate;
	
	/*
	 * getting the flight details
	 * 
	 * @param -Source ,destination
	 * 
	 * @return-List of flightResponseDto
	 */
	@GetMapping("/flights")
	public ResponseEntity<List<FlightResponseDto>> getFlights(@RequestParam("source") String source,@RequestParam("destination") String destination,
			@RequestParam("date")   Date date){
		List<FlightResponseDto> flightDtoList=restTemplate.getForEntity("http://SEARCH/flight/flights?source="+source+"&destination="+destination+"&date="+date, List.class).getBody();
		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList,HttpStatus.OK);
	}
	
	/*
	 * getting the flight details
	 * 
	 * @param -Source ,destination,flightname
	 * 
	 * @return-List of flightResponseDto
	 */
	@GetMapping("/flights/filterByName")
	public ResponseEntity<List<FlightResponseDto>> getFlightsByName(@RequestParam("source") String source,@RequestParam("destination") String destination,
			@RequestParam("date")   Date date,@RequestParam("name") String flightName){
		List<FlightResponseDto> flightDtoList=restTemplate.getForEntity("http://SEARCH/flight/flights?source="+source+"&destination="+destination+"&date="+date+"&name="+flightName, List.class).getBody();
		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList,HttpStatus.OK);
	}
	
	/*
	 * getting the flight details
	 * 
	 * @param -Source ,destination,cost
	 * 
	 * @return-List of flightResponseDto
	 */
	@GetMapping("/flights/filterByCost")
	public ResponseEntity<List<FlightResponseDto>> getFlightsByCost(@RequestParam("source") String source,@RequestParam("destination") String destination,
			@RequestParam("date")   Date date,@RequestParam("cost") double cost){
		List<FlightResponseDto> flightDtoList=restTemplate.getForEntity("http://SEARCH/flight/flights/filterByCost?source="+source+"&destination="+destination+"&date="+date+"&cost="+cost, List.class).getBody();
		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList,HttpStatus.OK);
	
	}
	
	/*
	 * getting the flight details
	 * 
	 * @param -Source ,destination,flightname,cost
	 * 
	 * @return-List of flightResponseDto
	 */
	@GetMapping("/flights/filterByNameCost")
	public ResponseEntity<List<FlightResponseDto>> getFlightsByNameCost(@RequestParam("source") String source,@RequestParam("destination") String destination,
			@RequestParam("date")   Date date,@RequestParam("name") String flightName,@RequestParam("cost") double cost){
		List<FlightResponseDto> flightDtoList=restTemplate.getForEntity("http://SEARCH/flight/flights/filterByNameCost?source="+source+"&destination="+destination+"&date="+date+"&name="+flightName+"&cost="+cost, List.class).getBody();
		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList,HttpStatus.OK);
	
	}
	
	/*
	 * booking flight ticket
	 * 
	 * @param- ticketrequestDto
	 * 
	 * @result-ticket Id
	 */
	@PostMapping("/tickets")
	public ResponseEntity<String> bookTicket(@RequestBody TicketRequestDto ticketRequestDto){
		String response=restTemplate.postForEntity("http://FLIGHTTICKET/ticket/tickets", ticketRequestDto,String.class).getBody();
		return new ResponseEntity<String>(response,HttpStatus.OK);
	}
	
	/*
	 * getting status of ticket id
	 * 
	 * @param- ticketId
	 * 
	 * @result-ticket details
	 */
	@GetMapping("/tickets")
	public ResponseEntity<TicketResponseDto> getStatus(@RequestParam("ticketId") Long ticketId ) {
		TicketResponseDto ticketResponseDto= restTemplate.getForEntity("http://FLIGHTTICKET/ticket/tickets?ticketId="+ticketId,TicketResponseDto.class).getBody();
		return new ResponseEntity<TicketResponseDto>(ticketResponseDto,HttpStatus.OK);
	}
}

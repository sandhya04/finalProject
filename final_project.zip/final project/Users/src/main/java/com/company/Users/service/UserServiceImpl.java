package com.company.Users.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.Users.Exception.UserNotFoundException;
import com.company.Users.dao.UserRepository;
import com.company.Users.dto.UserRequestDto;
import com.company.Users.model.User;
import com.company.Users.utilities.MD5Helper;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	MD5Helper md5Helper;
	/* saving the user in database */
	@Override
	public void saveUser(UserRequestDto userRequestDto) {
		// TODO Auto-generated method stub
		User user=modelMapper.map(userRequestDto,User.class);
		user.setPassword(md5Helper.getMd5(userRequestDto.getPassword()));
		userRepository.save(user);
	}

	@Override
	public void validateUser(String email, String password) {
		// TODO Auto-generated method stub
		String encryptedPassword=md5Helper.getMd5(password);
		User user=userRepository.findByEmailAndPassword(email,encryptedPassword);
		if(user==null) throw new UserNotFoundException("User not found.please register." +email);
	}
	
	@Override
	public void getByUserId(Long userId) {
		Optional<User> user=userRepository.findById(userId);
		if(!user.isPresent())throw new UserNotFoundException("User not registered."+userId);
	
	}
}

package com.company.Users.dto;

import java.sql.Time;

import org.springframework.stereotype.Component;

@Component
public class FlightResponseDto {
	private String flightId;
	private String name;
	private Time departureTime;
	private Time arrivalTime;
	private String duration;
	private double costBusinessSeat;
	private double costEconomicSeat;
	private int businessSeats;
	private int economicSeats;
	
	public int getBusinessSeats() {
		return businessSeats;
	}
	public void setBusinessSeats(int businessSeats) {
		this.businessSeats = businessSeats;
	}
	public int getEconomicSeats() {
		return economicSeats;
	}
	public void setEconomicSeats(int economicSeats) {
		this.economicSeats = economicSeats;
	}
	public double getCostBusinessSeat() {
		return costBusinessSeat;
	}
	public void setCostBusinessSeat(double costBusinessSeat) {
		this.costBusinessSeat = costBusinessSeat;
	}
	public double getCostEconomicSeat() {
		return costEconomicSeat;
	}
	public void setCostEconomicSeat(double costEconomicSeat) {
		this.costEconomicSeat = costEconomicSeat;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public Time getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(Time departureTime) {
		this.departureTime = departureTime;
	}
	public Time getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(Time arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	
}

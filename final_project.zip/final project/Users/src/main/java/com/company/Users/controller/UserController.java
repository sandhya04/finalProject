package com.company.Users.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.Users.dto.UserRequestDto;
import com.company.Users.model.User;
import com.company.Users.service.UserService;


@RestController
public class UserController {

	private final Logger LOGGER=LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	UserService userService;

	/*
	 * saving user details in database
	 */
	@PostMapping("/users")
	public ResponseEntity<Object> saveUser(@RequestBody UserRequestDto userRequestDto) {
		userService.saveUser(userRequestDto);
		return new ResponseEntity<>("Success",HttpStatus.CREATED);
	}
	
	/*
	 * validating user credentials.
	 */
	@GetMapping("/users")
	public ResponseEntity<Object> validateUser(@RequestParam("email") String email,@RequestParam("password")String password) {
		userService.validateUser(email, password);
		return new ResponseEntity<>("Success",HttpStatus.OK);
	}

	/*
	 * getting user details by using user id.
	 */
	@GetMapping("/users/{userId}")
	public ResponseEntity<User> getByUser(@PathVariable("userId") Long userId){
		userService.getByUserId(userId);
	return new ResponseEntity<User>(HttpStatus.OK);
	}
}

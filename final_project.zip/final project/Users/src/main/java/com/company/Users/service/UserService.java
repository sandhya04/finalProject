package com.company.Users.service;

import com.company.Users.dto.UserRequestDto;
import com.company.Users.model.User;

public interface UserService {
public void saveUser(UserRequestDto userRequestDto);
public void validateUser(String email,String password);
public void getByUserId(Long userId);
}
